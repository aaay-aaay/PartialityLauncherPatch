IF THIS DIRECTORY DOES NOT CONTAIN A .DLL FILE YOU HAVE DOWNLOADED THE WRONG THING! https://github.com/aaay-aaay/PartialityLauncherPatch/releases

There are two methods to install this patch:
1. Copy the PartialityLauncher.dll into Partiality's bin folder. This is very simple but only works if the .dll used to make this PartialityLauncher.dll is the same as the one you are using.
2. Copy the PartialityLauncher.patch.mm.dll into Partiality's bin folder, then open a cmd and type MonoMod.exe PartialityLauncher.dll. This will probably work for most recent versions of Partiality, unless something gets changed.

The patch will make the partiality launcher window much smaller, so that it will (hopefully) work with smaller resolutions.